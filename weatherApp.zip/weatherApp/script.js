var API = {
    key: '3b3a1464e1efd55900e820c14b3f6795',
    base: 'http://api.openweathermap.org/data/2.5/'

}

const searchBox = document.querySelector('.search-box');
searchBox.addEventListener('keypress', setQuery)


function setQuery(e){
    if (e.keyCode === 13){
        getResults(searchBox.value);
    }
}


function getResults(name){
    fetch(`${API.base}weather?q=${name}&units=metric&APPID=${API.key}`)
    .then(response => {
        return response.json();
    }).then(displayResults)
}



function displayResults(response){
    let city = document.querySelector('.city');
    city.innerText = `${response.name}, ${response.sys.country}`;
    let now = new Date();
    let date = document.querySelector('.date');
    date.innerText = dateBuilder(now);

    let temp = document.querySelector('.temp');
    temp.innerHTML = `${Math.round(response.main.temp)}<span>°C</span>`;
    let weatherElement = document.querySelector('.weather');
    weatherElement.innerText = response.weather[0].main;
    let highLow = document.querySelector('.hi-low');
    highLow.innerText = `${Math.round(response.main.temp_min)}°C /${Math.round(response.main.temp_max)}°C`;

}

function dateBuilder(d){
    let months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    let days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    let day = days[d.getDay()];
    let date = d.getDate();
    let month = months[d.getMonth()];
    let year = d.getFullYear();

    return `${day} ${date} ${month} ${year}`;
}